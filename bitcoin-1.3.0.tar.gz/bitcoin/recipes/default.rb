#
# Cookbook Name:: bitcoin
# Recipe:: default
#

raise "bitcoin::default is a NOOP"
