Bitcoin CHANGELOG
=================

## v1.3.0

- Add ability to run a Bitcoin fork/variant.

## v1.2.0
- Add recipe to compile Bitcoin from source - thanks @facastagnini!
- Improve init.d script.
- Update Bitcoin release for binary recipe.

## v1.1.0
- Add recipe to install RPM package.

## v1.0.1
- Code formatting and various tweaks. No functional changes.

## v1.0.0
- Initial release.

